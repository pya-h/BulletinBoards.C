#include "BOARDS-DATA.H"

#include <ctype.h>
#include <string.h>

void SetImportance(struct TASK *Task)
{
    // Harf avval ->Importance Ra Check mikonad va Meghdar Motabar daronash Gharar Midahad
    Task->Importance[0] = toupper(Task->Importance[0]);
    if (Task->Importance[0] = 'H')
    {
        strcpy(Task->Importance, "High"); // Kamel kardane matn Importance
    }
    else if (Task->Importance[0] = 'M')
    {
        strcpy(Task->Importance, "Medium"); // Kamel kardane matn Importance
    }
    else if (Task->Importance[0] = 'L')
    {
        strcpy(Task->Importance, "Low"); // Kamel kardane matn Importance
    }
}
void WriteData(char *UserName,  struct BOARD Boards[])
{
    FILE *CsvFile = fopen(UserName, "w");
    
    if(CsvFile == NULL) {
        return;
    }

    
}